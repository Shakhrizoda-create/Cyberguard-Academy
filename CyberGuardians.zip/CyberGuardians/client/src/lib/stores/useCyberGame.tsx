import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GamePhase = "menu" | "intro" | "scenario" | "challenge" | "feedback" | "complete";

export interface Scenario {
  id: string;
  title: string;
  description: string;
  type: "phishing" | "password" | "wifi" | "social";
  completed: boolean;
}

export interface ChallengeResult {
  correct: boolean;
  explanation: string;
  tip: string;
}

interface CyberGameState {
  phase: GamePhase;
  currentScenario: string | null;
  score: number;
  scenariosCompleted: string[];
  scenarios: Scenario[];
  currentChallengeResult: ChallengeResult | null;
  
  setPhase: (phase: GamePhase) => void;
  setCurrentScenario: (scenarioId: string | null) => void;
  completeScenario: (scenarioId: string, correct: boolean) => void;
  setChallengeResult: (result: ChallengeResult) => void;
  resetGame: () => void;
}

const initialScenarios: Scenario[] = [
  {
    id: "phishing",
    title: "Suspicious Email",
    description: "You receive an urgent email claiming to be from your bank",
    type: "phishing",
    completed: false
  },
  {
    id: "password",
    title: "Creating Accounts",
    description: "Time to create a new password for your social media",
    type: "password",
    completed: false
  },
  {
    id: "wifi",
    title: "Free WiFi at Café",
    description: "You're at a coffee shop and see a free WiFi network",
    type: "wifi",
    completed: false
  },
  {
    id: "social",
    title: "Unexpected Message",
    description: "A stranger sends you a suspicious link on social media",
    type: "social",
    completed: false
  },
  {
    id: "twofactor",
    title: "Account Security",
    description: "Setting up protection for your important accounts",
    type: "phishing",
    completed: false
  },
  {
    id: "privacy",
    title: "App Permissions",
    description: "A new app asks for access to your personal data",
    type: "social",
    completed: false
  }
];

export const useCyberGame = create<CyberGameState>()(
  subscribeWithSelector((set) => ({
    phase: "menu",
    currentScenario: null,
    score: 0,
    scenariosCompleted: [],
    scenarios: initialScenarios,
    currentChallengeResult: null,
    
    setPhase: (phase) => set({ phase }),
    
    setCurrentScenario: (scenarioId) => set({ currentScenario: scenarioId }),
    
    completeScenario: (scenarioId, correct) => set((state) => {
      const newScore = correct ? state.score + 25 : state.score + 10;
      const newCompleted = [...state.scenariosCompleted, scenarioId];
      const updatedScenarios = state.scenarios.map(s => 
        s.id === scenarioId ? { ...s, completed: true } : s
      );
      
      if (typeof window !== 'undefined') {
        import('./useBadges').then(({ useBadges }) => {
          const badgesStore = useBadges.getState();
          badgesStore.checkAndAwardBadges(newScore, newCompleted, state.scenarios.length);
        });
      }
      
      return {
        score: newScore,
        scenariosCompleted: newCompleted,
        scenarios: updatedScenarios
      };
    }),
    
    setChallengeResult: (result) => set({ currentChallengeResult: result }),
    
    resetGame: () => set({
      phase: "menu",
      currentScenario: null,
      score: 0,
      scenariosCompleted: [],
      scenarios: initialScenarios,
      currentChallengeResult: null
    })
  }))
);
