import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedAt?: Date;
}

interface BadgesState {
  badges: Badge[];
  earnBadge: (badgeId: string) => void;
  checkAndAwardBadges: (score: number, scenariosCompleted: string[], allScenarios: number) => void;
  resetBadges: () => void;
}

const initialBadges: Badge[] = [
  {
    id: "first-steps",
    name: "First Steps",
    description: "Complete your first scenario",
    icon: "🎯",
    earned: false
  },
  {
    id: "phishing-expert",
    name: "Phishing Expert",
    description: "Successfully spot a phishing email",
    icon: "🎣",
    earned: false
  },
  {
    id: "password-master",
    name: "Password Master",
    description: "Create a strong password (70+ score)",
    icon: "🔐",
    earned: false
  },
  {
    id: "wifi-warrior",
    name: "WiFi Warrior",
    description: "Make a safe WiFi choice",
    icon: "📶",
    earned: false
  },
  {
    id: "social-savvy",
    name: "Social Savvy",
    description: "Avoid a social engineering scam",
    icon: "🛡️",
    earned: false
  },
  {
    id: "security-champion",
    name: "Security Champion",
    description: "Enable two-factor authentication",
    icon: "🏆",
    earned: false
  },
  {
    id: "privacy-guardian",
    name: "Privacy Guardian",
    description: "Protect your data by managing app permissions",
    icon: "🔒",
    earned: false
  },
  {
    id: "perfect-score",
    name: "Perfect Score",
    description: "Get all scenarios correct on first try",
    icon: "⭐",
    earned: false
  },
  {
    id: "cyber-defender",
    name: "Cyber Defender",
    description: "Complete all cybersecurity scenarios",
    icon: "🦸",
    earned: false
  },
  {
    id: "high-achiever",
    name: "High Achiever",
    description: "Score 125+ points (average 21+ per scenario)",
    icon: "💯",
    earned: false
  }
];

export const useBadges = create<BadgesState>()(
  persist(
    (set, get) => ({
      badges: initialBadges,

      earnBadge: (badgeId: string) => {
        set((state) => ({
          badges: state.badges.map((badge) =>
            badge.id === badgeId && !badge.earned
              ? { ...badge, earned: true, earnedAt: new Date() }
              : badge
          )
        }));
      },

      checkAndAwardBadges: (score: number, scenariosCompleted: string[], allScenarios: number) => {
        const { earnBadge, badges } = get();

        if (scenariosCompleted.length === 1 && !badges.find(b => b.id === "first-steps")?.earned) {
          earnBadge("first-steps");
        }

        if (scenariosCompleted.includes("phishing") && !badges.find(b => b.id === "phishing-expert")?.earned) {
          earnBadge("phishing-expert");
        }

        if (scenariosCompleted.includes("password") && !badges.find(b => b.id === "password-master")?.earned) {
          earnBadge("password-master");
        }

        if (scenariosCompleted.includes("wifi") && !badges.find(b => b.id === "wifi-warrior")?.earned) {
          earnBadge("wifi-warrior");
        }

        if (scenariosCompleted.includes("social") && !badges.find(b => b.id === "social-savvy")?.earned) {
          earnBadge("social-savvy");
        }

        if (scenariosCompleted.includes("twofactor") && !badges.find(b => b.id === "security-champion")?.earned) {
          earnBadge("security-champion");
        }

        if (scenariosCompleted.includes("privacy") && !badges.find(b => b.id === "privacy-guardian")?.earned) {
          earnBadge("privacy-guardian");
        }

        if (scenariosCompleted.length === allScenarios && !badges.find(b => b.id === "cyber-defender")?.earned) {
          earnBadge("cyber-defender");
        }

        const maxPossible = allScenarios * 25;
        if (score === maxPossible && scenariosCompleted.length === allScenarios && !badges.find(b => b.id === "perfect-score")?.earned) {
          earnBadge("perfect-score");
        }

        if (score >= 125 && !badges.find(b => b.id === "high-achiever")?.earned) {
          earnBadge("high-achiever");
        }
      },

      resetBadges: () => set({ badges: initialBadges })
    }),
    {
      name: "cyberguard-badges"
    }
  )
);
