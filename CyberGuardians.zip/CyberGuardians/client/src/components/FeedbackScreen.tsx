import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useBadges } from "@/lib/stores/useBadges";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, Trophy, ArrowRight } from "lucide-react";
import BadgesDisplay from "./BadgesDisplay";
import StatisticsPanel from "./StatisticsPanel";

export default function FeedbackScreen() {
  const { setPhase, currentChallengeResult, scenarios, setCurrentScenario, scenariosCompleted, currentScenario } = useCyberGame();
  const { badges } = useBadges();
  const newBadgesEarned = badges.filter(b => b.earned && b.earnedAt && 
    new Date().getTime() - new Date(b.earnedAt).getTime() < 5000
  );

  const handleContinue = () => {
    const nextIncomplete = scenarios.find(s => !s.completed);
    
    if (nextIncomplete) {
      setCurrentScenario(nextIncomplete.id);
      setPhase("scenario");
    } else {
      setPhase("complete");
    }
  };

  if (!currentChallengeResult) return null;

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-green-900 via-teal-900 to-blue-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Trophy className={`w-16 h-16 ${
                currentChallengeResult.correct ? 'text-yellow-500' : 'text-gray-400'
              }`} />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {currentChallengeResult.correct ? "Well Done!" : "You've Learned Something!"}
            </h2>
            <p className="text-gray-600">
              Scenario {scenariosCompleted.length} of {scenarios.length} completed
            </p>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 rounded-lg p-6 mb-6">
            <h3 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <span className="text-2xl">📚</span> What Happened
            </h3>
            <p className="text-gray-800">
              {currentChallengeResult.explanation}
            </p>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-500 rounded-lg p-6 mb-8">
            <h3 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-yellow-600" />
              Security Tip
            </h3>
            <p className="text-gray-800">
              {currentChallengeResult.tip}
            </p>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Points Earned</p>
                <p className="text-3xl font-bold text-purple-600">
                  +{currentChallengeResult.correct ? 25 : 10}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Progress</p>
                <p className="text-3xl font-bold text-blue-600">
                  {scenariosCompleted.length}/{scenarios.length}
                </p>
              </div>
            </div>
          </div>

          {newBadgesEarned.length > 0 && (
            <div className="bg-gradient-to-r from-yellow-100 to-orange-100 border-2 border-yellow-400 rounded-lg p-6 mb-6 animate-pulse">
              <h3 className="font-bold text-gray-900 mb-3 text-center text-lg">
                🎉 New Badge Earned! 🎉
              </h3>
              <div className="flex justify-center gap-4">
                {newBadgesEarned.map((badge) => (
                  <div key={badge.id} className="text-center bg-white rounded-lg p-4 shadow">
                    <div className="text-5xl mb-2">{badge.icon}</div>
                    <p className="font-bold text-gray-900">{badge.name}</p>
                    <p className="text-sm text-gray-600">{badge.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mb-6">
            <BadgesDisplay compact />
          </div>

          {currentScenario && (
            <div className="mb-6">
              <StatisticsPanel scenarioType={currentScenario} />
            </div>
          )}

          <Button 
            onClick={handleContinue}
            className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            {scenarios.find(s => !s.completed) ? (
              <>Next Scenario <ArrowRight className="ml-2 w-5 h-5" /></>
            ) : (
              <>View Results <ArrowRight className="ml-2 w-5 h-5" /></>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
