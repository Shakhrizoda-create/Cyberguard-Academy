import { useCyberGame } from "@/lib/stores/useCyberGame";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

export default function IntroScreen() {
  const { setPhase, setCurrentScenario, scenarios } = useCyberGame();

  const handleStart = () => {
    const firstIncomplete = scenarios.find(s => !s.completed);
    if (firstIncomplete) {
      setCurrentScenario(firstIncomplete.id);
      setPhase("scenario");
    } else {
      setPhase("complete");
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-indigo-900 via-blue-900 to-purple-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            Welcome, Cyber Defender!
          </h2>
          
          <div className="space-y-4 mb-8">
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
              <h3 className="font-semibold text-gray-900 mb-2">Your Mission</h3>
              <p className="text-gray-700 text-sm">
                Navigate through real-world cybersecurity scenarios and make the right choices to protect yourself from hackers and scammers.
              </p>
            </div>

            <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
              <h3 className="font-semibold text-gray-900 mb-2">How It Works</h3>
              <ul className="text-gray-700 text-sm space-y-1 list-disc list-inside">
                <li>Read each scenario carefully</li>
                <li>Make decisions or complete challenges</li>
                <li>Learn from immediate feedback</li>
                <li>Earn points for correct answers (25 points) or learning (10 points)</li>
              </ul>
            </div>

            <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
              <h3 className="font-semibold text-gray-900 mb-2">What You'll Learn</h3>
              <div className="grid grid-cols-2 gap-2 text-sm text-gray-700">
                <div>✓ Spotting phishing emails</div>
                <div>✓ Creating strong passwords</div>
                <div>✓ Safe WiFi usage</div>
                <div>✓ Avoiding social engineering</div>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleStart}
            className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            Begin Your Training <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
