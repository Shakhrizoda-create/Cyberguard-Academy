import { Shield, Lock, Wifi, MessageSquare, Award } from "lucide-react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function MainMenu() {
  const { setPhase } = useCyberGame();

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Shield className="w-20 h-20 text-blue-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-3">
              CyberGuard Academy
            </h1>
            <p className="text-lg text-gray-700 mb-2">
              Learn to protect yourself from cyber threats
            </p>
            <p className="text-sm text-gray-600">
              An interactive game to increase cybersecurity awareness
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg text-center">
              <Lock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-900">Phishing Detection</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg text-center">
              <Award className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-900">Password Security</p>
            </div>
            <div className="bg-indigo-50 p-4 rounded-lg text-center">
              <Wifi className="w-8 h-8 text-indigo-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-900">Safe Browsing</p>
            </div>
            <div className="bg-pink-50 p-4 rounded-lg text-center">
              <MessageSquare className="w-8 h-8 text-pink-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-900">Social Engineering</p>
            </div>
          </div>

          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-800 text-center">
              <strong>⚠️ Important:</strong> Hacking is common in your community. 
              Learn how to protect yourself and your data!
            </p>
          </div>

          <Button 
            onClick={() => setPhase("intro")}
            className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            Start Learning
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
