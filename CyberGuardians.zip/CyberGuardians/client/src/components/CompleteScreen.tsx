import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useBadges } from "@/lib/stores/useBadges";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Shield, Star, RotateCcw, CheckCircle } from "lucide-react";
import BadgesDisplay from "./BadgesDisplay";

export default function CompleteScreen() {
  const { score, scenarios, resetGame } = useCyberGame();
  const { resetBadges } = useBadges();

  const totalPossible = scenarios.length * 25;
  const percentage = Math.round((score / totalPossible) * 100);

  const getGrade = () => {
    if (percentage >= 90) return { letter: "A+", color: "text-green-600", message: "Outstanding!" };
    if (percentage >= 80) return { letter: "A", color: "text-green-500", message: "Excellent!" };
    if (percentage >= 70) return { letter: "B", color: "text-blue-500", message: "Great job!" };
    if (percentage >= 60) return { letter: "C", color: "text-yellow-500", message: "Good effort!" };
    return { letter: "D", color: "text-orange-500", message: "Keep learning!" };
  };

  const grade = getGrade();

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-yellow-900 via-orange-900 to-red-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Trophy className="w-20 h-20 text-yellow-500 animate-pulse" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Training Complete!
            </h1>
            <p className="text-lg text-gray-700">
              You've completed all cybersecurity scenarios
            </p>
          </div>

          <div className="bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg p-8 mb-6 text-center">
            <p className="text-sm text-gray-600 mb-2">Your Final Score</p>
            <p className="text-6xl font-bold text-purple-600 mb-2">{score}</p>
            <p className="text-lg text-gray-700 mb-4">out of {totalPossible} points</p>
            <div className="flex items-center justify-center gap-4">
              <div className={`text-5xl font-bold ${grade.color}`}>{grade.letter}</div>
              <div className="text-left">
                <p className="text-2xl font-bold text-gray-900">{percentage}%</p>
                <p className="text-sm text-gray-600">{grade.message}</p>
              </div>
            </div>
          </div>

          <div className="grid gap-4 mb-8">
            <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="w-6 h-6 text-green-600" />
                <h3 className="font-bold text-gray-900">Scenarios Completed</h3>
              </div>
              <div className="space-y-2">
                {scenarios.map((scenario) => (
                  <div key={scenario.id} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-gray-800">{scenario.title}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <Star className="w-6 h-6 text-blue-600" />
                <h3 className="font-bold text-gray-900">Key Takeaways</h3>
              </div>
              <ul className="text-sm text-gray-700 space-y-2">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Always verify the sender before clicking links in emails</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Use strong, unique passwords for each account (12+ characters)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Avoid public WiFi for sensitive activities or use a VPN</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Be skeptical of messages from strangers offering free money</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-800 text-center">
              <strong>🛡️ Stay Safe:</strong> Apply these lessons in your daily life to protect yourself from hackers and scammers in your community!
            </p>
          </div>

          <div className="mb-6">
            <BadgesDisplay />
          </div>

          <Button 
            onClick={() => {
              resetGame();
              resetBadges();
            }}
            className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <RotateCcw className="mr-2 w-5 h-5" />
            Practice Again
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
