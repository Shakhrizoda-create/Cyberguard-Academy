import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function GameUI() {
  const { score, scenariosCompleted, scenarios } = useCyberGame();
  const { isMuted, toggleMute } = useAudio();

  return (
    <div className="fixed top-0 left-0 right-0 z-50 pointer-events-none">
      <div className="p-4 flex justify-between items-start">
        <div className="bg-white/90 backdrop-blur rounded-lg px-6 py-3 shadow-lg pointer-events-auto">
          <div className="flex items-center gap-6">
            <div>
              <p className="text-xs text-gray-600 font-semibold">SCORE</p>
              <p className="text-2xl font-bold text-purple-600">{score}</p>
            </div>
            <div className="h-10 w-px bg-gray-300" />
            <div>
              <p className="text-xs text-gray-600 font-semibold">PROGRESS</p>
              <p className="text-2xl font-bold text-blue-600">
                {scenariosCompleted.length}/{scenarios.length}
              </p>
            </div>
          </div>
        </div>

        <Button
          onClick={toggleMute}
          variant="outline"
          size="icon"
          className="bg-white/90 backdrop-blur shadow-lg pointer-events-auto hover:bg-white/95"
        >
          {isMuted ? (
            <VolumeX className="w-5 h-5 text-gray-600" />
          ) : (
            <Volume2 className="w-5 h-5 text-blue-600" />
          )}
        </Button>
      </div>
    </div>
  );
}
