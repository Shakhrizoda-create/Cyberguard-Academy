import { useState, useEffect } from "react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, AlertTriangle, CheckCircle2 } from "lucide-react";

export default function PhishingScenario() {
  const { setPhase, completeScenario, setChallengeResult } = useCyberGame();
  const { playSuccess, playHit } = useAudio();
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    setSelectedOption(null);
    setShowResult(false);
  }, []);

  const emailContent = {
    from: "security@bankalert-verify.com",
    subject: "URGENT: Your Account Has Been Suspended!",
    body: `Dear Valued Customer,

We have detected unusual activity on your account. Your account has been temporarily suspended for security reasons.

To restore access immediately, please verify your identity by clicking the link below:

VERIFY MY ACCOUNT NOW

If you do not verify within 24 hours, your account will be permanently closed.

Thank you,
Customer Security Team`
  };

  const options = [
    {
      id: "click",
      text: "Click the link immediately to verify my account",
      correct: false
    },
    {
      id: "reply",
      text: "Reply to the email asking for more information",
      correct: false
    },
    {
      id: "ignore",
      text: "Delete the email and contact my bank directly using their official website or phone number",
      correct: true
    },
    {
      id: "forward",
      text: "Forward it to my contacts to warn them",
      correct: false
    }
  ];

  const handleChoice = (optionId: string) => {
    const option = options.find(o => o.id === optionId);
    if (!option) return;

    setSelectedOption(optionId);
    setShowResult(true);

    if (option.correct) {
      playSuccess();
      setChallengeResult({
        correct: true,
        explanation: "Excellent choice! This email shows classic signs of phishing: suspicious sender address, urgency tactics, and requests for verification via link.",
        tip: "Always contact your bank directly using official contact information, never through links in emails. Look for red flags like misspelled domains (bankalert-verify.com vs your actual bank)."
      });
      completeScenario("phishing", true);
    } else {
      playHit();
      let explanation = "";
      if (optionId === "click") {
        explanation = "Clicking suspicious links can install malware or steal your credentials through fake login pages.";
      } else if (optionId === "reply") {
        explanation = "Replying confirms your email is active and may lead to more phishing attempts.";
      } else if (optionId === "forward") {
        explanation = "Forwarding phishing emails can spread the threat to others.";
      }
      
      setChallengeResult({
        correct: false,
        explanation: `Not the best choice. ${explanation} The correct action is to contact your bank directly using official channels.`,
        tip: "Red flags to spot: Generic greetings, urgent threats, suspicious email addresses, poor grammar, and requests to click links or provide sensitive information."
      });
      completeScenario("phishing", false);
    }
  };

  const handleContinue = () => {
    setPhase("feedback");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-red-900 via-orange-900 to-yellow-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <Mail className="w-8 h-8 text-red-600" />
            <h2 className="text-3xl font-bold text-gray-900">Scenario: Suspicious Email</h2>
          </div>

          <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-800">
                You just received this email. Read it carefully and decide what to do.
              </p>
            </div>
          </div>

          <div className="bg-gray-100 border-2 border-gray-300 rounded-lg p-6 mb-6 font-mono text-sm">
            <div className="mb-4 pb-4 border-b border-gray-300">
              <p className="text-gray-600"><strong>From:</strong> {emailContent.from}</p>
              <p className="text-gray-900 mt-2"><strong>Subject:</strong> {emailContent.subject}</p>
            </div>
            <div className="whitespace-pre-line text-gray-800">
              {emailContent.body}
            </div>
          </div>

          {!showResult ? (
            <div className="space-y-3">
              <p className="font-semibold text-gray-900 mb-3">What should you do?</p>
              {options.map((option) => (
                <Button
                  key={option.id}
                  onClick={() => handleChoice(option.id)}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-4 px-4 hover:bg-blue-50 hover:border-blue-400"
                >
                  {option.text}
                </Button>
              ))}
            </div>
          ) : (
            <div>
              {selectedOption && (
                <div className={`border-2 rounded-lg p-6 mb-4 ${
                  options.find(o => o.id === selectedOption)?.correct 
                    ? 'bg-green-50 border-green-400' 
                    : 'bg-red-50 border-red-400'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    {options.find(o => o.id === selectedOption)?.correct ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-green-900">Correct!</h3>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                        <h3 className="text-xl font-bold text-red-900">Not Quite</h3>
                      </>
                    )}
                  </div>
                  <p className="text-gray-800 font-semibold mb-2">Your choice:</p>
                  <p className="text-gray-700 mb-4">{options.find(o => o.id === selectedOption)?.text}</p>
                </div>
              )}
              
              <Button 
                onClick={handleContinue}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Continue
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
