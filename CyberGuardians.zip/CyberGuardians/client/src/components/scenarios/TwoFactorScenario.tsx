import { useState, useEffect } from "react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Smartphone, AlertTriangle, CheckCircle2, Shield } from "lucide-react";

export default function TwoFactorScenario() {
  const { setPhase, completeScenario, setChallengeResult } = useCyberGame();
  const { playSuccess, playHit } = useAudio();
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    setSelectedOption(null);
    setShowResult(false);
  }, []);

  const situation = {
    context: "You're setting up a new online account for your email. The website offers several security options.",
    question: "Which security setup provides the best protection for your account?"
  };

  const options = [
    {
      id: "password-only",
      text: "Just use a strong password - that's enough security",
      correct: false,
      icon: "🔒"
    },
    {
      id: "sms-2fa",
      text: "Enable two-factor authentication (2FA) with SMS codes sent to my phone",
      correct: true,
      icon: "📱"
    },
    {
      id: "security-questions",
      text: "Set up security questions like 'What's your mother's maiden name?'",
      correct: false,
      icon: "❓"
    },
    {
      id: "email-recovery",
      text: "Use email recovery only - no extra steps needed",
      correct: false,
      icon: "✉️"
    }
  ];

  const handleChoice = (optionId: string) => {
    const option = options.find(o => o.id === optionId);
    if (!option) return;

    setSelectedOption(optionId);
    setShowResult(true);

    if (option.correct) {
      playSuccess();
      setChallengeResult({
        correct: true,
        explanation: "Excellent! Two-factor authentication adds a critical second layer of security. Even if someone steals your password, they can't access your account without the code sent to your phone.",
        tip: "Use 2FA whenever available. Authenticator apps (like Google Authenticator or Authy) are even more secure than SMS. Never share your 2FA codes with anyone - legitimate companies will never ask for them!"
      });
      completeScenario("twofactor", true);
    } else {
      playHit();
      let explanation = "";
      if (optionId === "password-only") {
        explanation = "Passwords alone can be stolen, guessed, or leaked in data breaches. 62% of data breaches involve weak or stolen passwords.";
      } else if (optionId === "security-questions") {
        explanation = "Security questions are weak because answers can often be found on social media or guessed. Your mother's maiden name isn't a secret!";
      } else if (optionId === "email-recovery") {
        explanation = "If hackers gain access to your email, they can reset passwords for all your other accounts. Email alone isn't secure enough.";
      }
      
      setChallengeResult({
        correct: false,
        explanation: `Not the best choice. ${explanation} Two-factor authentication provides much stronger protection.`,
        tip: "Enable 2FA on important accounts: email, banking, social media, and shopping sites. It takes 30 seconds to set up but can prevent years of identity theft problems."
      });
      completeScenario("twofactor", false);
    }
  };

  const handleContinue = () => {
    setPhase("feedback");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-green-900 via-teal-900 to-blue-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <Smartphone className="w-8 h-8 text-green-600" />
            <h2 className="text-3xl font-bold text-gray-900">Scenario: Account Security</h2>
          </div>

          <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-800 mb-3">
              {situation.context}
            </p>
            <div className="flex items-start gap-2 bg-white rounded p-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-gray-900 mb-1">Did you know?</p>
                <p className="text-sm text-gray-700">
                  Accounts with two-factor authentication are 99.9% less likely to be compromised, even if the password is stolen.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">What is Two-Factor Authentication (2FA)?</h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p className="flex items-start gap-2">
                <span className="text-green-600 font-bold">1️⃣</span>
                <span><strong>Something you know:</strong> Your password</span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-green-600 font-bold">2️⃣</span>
                <span><strong>Something you have:</strong> Your phone (receives the code)</span>
              </p>
              <p className="mt-3 text-gray-800">
                Both are required to log in, making your account much harder to hack!
              </p>
            </div>
          </div>

          {!showResult ? (
            <div className="space-y-3">
              <p className="font-semibold text-gray-900 mb-3">{situation.question}</p>
              {options.map((option) => (
                <Button
                  key={option.id}
                  onClick={() => handleChoice(option.id)}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-4 px-4 hover:bg-green-50 hover:border-green-400"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{option.icon}</span>
                    <span>{option.text}</span>
                  </div>
                </Button>
              ))}
            </div>
          ) : (
            <div>
              {selectedOption && (
                <div className={`border-2 rounded-lg p-6 mb-4 ${
                  options.find(o => o.id === selectedOption)?.correct 
                    ? 'bg-green-50 border-green-400' 
                    : 'bg-red-50 border-red-400'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    {options.find(o => o.id === selectedOption)?.correct ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-green-900">Great Choice!</h3>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                        <h3 className="text-xl font-bold text-red-900">Not Ideal</h3>
                      </>
                    )}
                  </div>
                  <p className="text-gray-800 font-semibold mb-2">Your choice:</p>
                  <p className="text-gray-700 mb-4 flex items-center gap-2">
                    <span className="text-2xl">{options.find(o => o.id === selectedOption)?.icon}</span>
                    {options.find(o => o.id === selectedOption)?.text}
                  </p>
                </div>
              )}

              <div className="bg-yellow-50 border-l-4 border-yellow-400 rounded p-4 mb-4">
                <h4 className="font-semibold text-gray-900 mb-2 text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  Beware of Fake 2FA Requests!
                </h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Never give your 2FA code to anyone, even if they claim to be from support</li>
                  <li>• Real companies will never call or email asking for your 2FA code</li>
                  <li>• If you receive an unexpected 2FA code, someone may be trying to access your account</li>
                </ul>
              </div>
              
              <Button 
                onClick={handleContinue}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Continue
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
