import { useState, useEffect } from "react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Wifi, AlertTriangle, CheckCircle2, Lock } from "lucide-react";

export default function WiFiScenario() {
  const { setPhase, completeScenario, setChallengeResult } = useCyberGame();
  const { playSuccess, playHit } = useAudio();
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    setSelectedNetwork(null);
    setShowResult(false);
  }, []);

  const networks = [
    {
      id: "free-wifi",
      name: "FREE-CAFE-WIFI",
      icon: <Wifi className="w-5 h-5" />,
      secure: false,
      description: "Open network, no password required"
    },
    {
      id: "cafe-guest",
      name: "CafeGuest-Secure",
      icon: <Lock className="w-5 h-5" />,
      secure: false,
      description: "Password available at counter"
    },
    {
      id: "mobile",
      name: "My Mobile Hotspot",
      icon: <Lock className="w-5 h-5" />,
      secure: true,
      description: "Your personal hotspot"
    }
  ];

  const handleChoice = (networkId: string) => {
    const network = networks.find(n => n.id === networkId);
    if (!network) return;

    setSelectedNetwork(networkId);
    setShowResult(true);

    if (network.secure) {
      playSuccess();
      setChallengeResult({
        correct: true,
        explanation: "Excellent! Using your personal mobile hotspot is the safest option when handling sensitive information in public places.",
        tip: "Public WiFi networks can be monitored by hackers who can intercept your data. For sensitive activities (banking, shopping, work), always use a trusted network or your mobile hotspot. If you must use public WiFi, use a VPN."
      });
      completeScenario("wifi", true);
    } else {
      playHit();
      let explanation = "";
      if (networkId === "free-wifi") {
        explanation = "Open WiFi networks are the most dangerous. Hackers can easily intercept your data, see what websites you visit, and even steal passwords or credit card information.";
      } else if (networkId === "cafe-guest") {
        explanation = "Even password-protected public WiFi can be risky. The password is shared with everyone, meaning other users and potential hackers on the same network can monitor your activity.";
      }
      
      setChallengeResult({
        correct: false,
        explanation: `Risky choice! ${explanation}`,
        tip: "When using public WiFi: Avoid accessing bank accounts or entering passwords, use HTTPS websites (look for the padlock icon), consider using a VPN, and turn off file sharing on your device."
      });
      completeScenario("wifi", false);
    }
  };

  const handleContinue = () => {
    setPhase("feedback");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-cyan-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <Wifi className="w-8 h-8 text-cyan-600" />
            <h2 className="text-3xl font-bold text-gray-900">Scenario: Free WiFi at Café</h2>
          </div>

          <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-800">
              You're at a coffee shop and need to check your bank account balance on your phone. You see several WiFi networks available. Which one should you use?
            </p>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-gray-900 mb-1">Think carefully!</p>
                <p className="text-sm text-gray-700">
                  You're about to access sensitive financial information. Security should be your priority.
                </p>
              </div>
            </div>
          </div>

          {!showResult ? (
            <div className="space-y-4">
              <p className="font-semibold text-gray-900 mb-3">Available Networks:</p>
              {networks.map((network) => (
                <Button
                  key={network.id}
                  onClick={() => handleChoice(network.id)}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-6 px-6 hover:bg-blue-50 hover:border-blue-400"
                >
                  <div className="flex items-center gap-4 w-full">
                    <div className={`p-3 rounded-lg ${
                      network.id === "mobile" ? "bg-green-100" : "bg-gray-100"
                    }`}>
                      {network.icon}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900">{network.name}</div>
                      <div className="text-sm text-gray-600">{network.description}</div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          ) : (
            <div>
              {selectedNetwork && (
                <div className={`border-2 rounded-lg p-6 mb-4 ${
                  networks.find(n => n.id === selectedNetwork)?.secure
                    ? 'bg-green-50 border-green-400' 
                    : 'bg-red-50 border-red-400'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    {networks.find(n => n.id === selectedNetwork)?.secure ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-green-900">Safe Choice!</h3>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                        <h3 className="text-xl font-bold text-red-900">Risky Choice!</h3>
                      </>
                    )}
                  </div>
                  <p className="text-gray-800 font-semibold mb-2">You chose:</p>
                  <p className="text-gray-700 mb-4">
                    {networks.find(n => n.id === selectedNetwork)?.name} - {networks.find(n => n.id === selectedNetwork)?.description}
                  </p>
                </div>
              )}

              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h4 className="font-semibold text-gray-900 mb-2 text-sm">Public WiFi Safety Tips:</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Use your mobile hotspot for sensitive activities</li>
                  <li>• Look for "HTTPS" and padlock icon in browser</li>
                  <li>• Use a VPN (Virtual Private Network) for extra security</li>
                  <li>• Avoid online banking and shopping on public WiFi</li>
                  <li>• Turn off auto-connect to WiFi networks</li>
                </ul>
              </div>
              
              <Button 
                onClick={handleContinue}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Continue
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
