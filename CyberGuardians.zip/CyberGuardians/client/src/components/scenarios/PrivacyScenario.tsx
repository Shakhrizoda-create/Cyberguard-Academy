import { useState, useEffect } from "react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Eye, AlertTriangle, CheckCircle2, FileWarning } from "lucide-react";

export default function PrivacyScenario() {
  const { setPhase, completeScenario, setChallengeResult } = useCyberGame();
  const { playSuccess, playHit } = useAudio();
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    setSelectedOption(null);
    setShowResult(false);
  }, []);

  const appRequest = {
    name: "Fun Photo Editor",
    category: "Photo & Video",
    permissions: [
      { name: "Camera", icon: "📷", necessary: true },
      { name: "Photo Library", icon: "🖼️", necessary: true },
      { name: "Contacts", icon: "👥", necessary: false, risky: true },
      { name: "Location", icon: "📍", necessary: false, risky: true },
      { name: "Microphone", icon: "🎤", necessary: false, risky: true },
      { name: "Call History", icon: "📞", necessary: false, risky: true }
    ]
  };

  const options = [
    {
      id: "accept-all",
      text: "Accept all permissions - I want to use the app quickly",
      correct: false
    },
    {
      id: "deny-all",
      text: "Deny all permissions - it's safer to not use the app",
      correct: false
    },
    {
      id: "selective",
      text: "Only allow Camera and Photo Library - deny unnecessary permissions like Contacts and Location",
      correct: true
    },
    {
      id: "check-later",
      text: "Accept now and change settings later if needed",
      correct: false
    }
  ];

  const handleChoice = (optionId: string) => {
    const option = options.find(o => o.id === optionId);
    if (!option) return;

    setSelectedOption(optionId);
    setShowResult(true);

    if (option.correct) {
      playSuccess();
      setChallengeResult({
        correct: true,
        explanation: "Perfect! You protected your privacy by only granting necessary permissions. A photo editor needs camera and photo access, but doesn't need your contacts, location, or call history.",
        tip: "Always ask: 'Why does this app need this permission?' A flashlight app doesn't need your contacts. A calculator doesn't need your location. Apps that ask for unnecessary permissions may be collecting data to sell to advertisers or worse."
      });
      completeScenario("privacy", true);
    } else {
      playHit();
      let explanation = "";
      if (optionId === "accept-all") {
        explanation = "Granting all permissions gives apps access to your personal data. Many apps collect and sell user data to third parties. In your community, data breaches have led to identity theft and fraud.";
      } else if (optionId === "deny-all") {
        explanation = "While cautious, denying all permissions means you can't use the app. The smarter approach is to grant only necessary permissions.";
      } else if (optionId === "check-later") {
        explanation = "Most people forget to review permissions later. Apps immediately start collecting data once granted access. It's better to make the right choice now.";
      }
      
      setChallengeResult({
        correct: false,
        explanation: `Not ideal. ${explanation} The best practice is to carefully review each permission and only allow what's necessary.`,
        tip: "Review app permissions regularly in your phone settings. Remove permissions you granted months ago but the app doesn't really need. Also check which apps have access to your microphone and camera!"
      });
      completeScenario("privacy", false);
    }
  };

  const handleContinue = () => {
    setPhase("feedback");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <Eye className="w-8 h-8 text-violet-600" />
            <h2 className="text-3xl font-bold text-gray-900">Scenario: App Permissions</h2>
          </div>

          <div className="bg-purple-50 border-2 border-purple-300 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-800 mb-3">
              You're installing <strong>"{appRequest.name}"</strong> to edit your photos. The app asks for the following permissions:
            </p>
          </div>

          <div className="bg-white border-2 border-gray-300 rounded-lg p-6 mb-6">
            <div className="flex items-center justify-between mb-4 pb-3 border-b">
              <div>
                <h3 className="font-bold text-gray-900">{appRequest.name}</h3>
                <p className="text-sm text-gray-600">{appRequest.category}</p>
              </div>
              <div className="text-4xl">📸</div>
            </div>

            <div className="space-y-2">
              <p className="font-semibold text-gray-900 text-sm mb-3">Requested Permissions:</p>
              {appRequest.permissions.map((perm, idx) => (
                <div 
                  key={idx}
                  className={`flex items-center justify-between p-3 rounded ${
                    perm.risky ? 'bg-red-50 border border-red-200' : 'bg-green-50 border border-green-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{perm.icon}</span>
                    <span className="font-medium text-gray-900">{perm.name}</span>
                  </div>
                  {perm.risky ? (
                    <span className="text-xs bg-red-600 text-white px-2 py-1 rounded">
                      ⚠️ Unnecessary
                    </span>
                  ) : (
                    <span className="text-xs bg-green-600 text-white px-2 py-1 rounded">
                      ✓ Needed
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 rounded p-4 mb-6">
            <div className="flex items-start gap-2">
              <FileWarning className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-gray-900 mb-1">Privacy Alert!</p>
                <p className="text-sm text-gray-700">
                  79% of apps collect more data than they need. Every unnecessary permission is a privacy risk.
                </p>
              </div>
            </div>
          </div>

          {!showResult ? (
            <div className="space-y-3">
              <p className="font-semibold text-gray-900 mb-3">What should you do?</p>
              {options.map((option) => (
                <Button
                  key={option.id}
                  onClick={() => handleChoice(option.id)}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-4 px-4 hover:bg-purple-50 hover:border-purple-400"
                >
                  {option.text}
                </Button>
              ))}
            </div>
          ) : (
            <div>
              {selectedOption && (
                <div className={`border-2 rounded-lg p-6 mb-4 ${
                  options.find(o => o.id === selectedOption)?.correct 
                    ? 'bg-green-50 border-green-400' 
                    : 'bg-red-50 border-red-400'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    {options.find(o => o.id === selectedOption)?.correct ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-green-900">Privacy Protected!</h3>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                        <h3 className="text-xl font-bold text-red-900">Privacy Risk!</h3>
                      </>
                    )}
                  </div>
                  <p className="text-gray-800 font-semibold mb-2">Your choice:</p>
                  <p className="text-gray-700 mb-4">{options.find(o => o.id === selectedOption)?.text}</p>
                </div>
              )}

              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h4 className="font-semibold text-gray-900 mb-2 text-sm">Privacy Protection Checklist:</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>✓ Only grant permissions the app truly needs</li>
                  <li>✓ Read app privacy policies before installing</li>
                  <li>✓ Check what data apps are collecting in settings</li>
                  <li>✓ Revoke permissions you granted but don't use anymore</li>
                  <li>✓ Be extra careful with location, contacts, and microphone access</li>
                  <li>✓ Uninstall apps you no longer use</li>
                </ul>
              </div>
              
              <Button 
                onClick={handleContinue}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Continue
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
document.getElementById("social-btn").addEventListener("click", openSocialGame);

function openSocialGame() {
  // Hide the main menu
  document.querySelector(".main-menu").style.display = "none";
  // Show the game area
  document.querySelector("#social-game").style.display = "block";
}
