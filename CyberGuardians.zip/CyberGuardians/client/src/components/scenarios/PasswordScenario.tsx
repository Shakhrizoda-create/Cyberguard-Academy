import { useState, useEffect } from "react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Lock, Eye, EyeOff, AlertTriangle, CheckCircle2 } from "lucide-react";

export default function PasswordScenario() {
  const { setPhase, completeScenario, setChallengeResult } = useCyberGame();
  const { playSuccess, playHit } = useAudio();
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [strength, setStrength] = useState<{
    score: number;
    issues: string[];
    strengths: string[];
  } | null>(null);

  useEffect(() => {
    setPassword("");
    setShowPassword(false);
    setShowResult(false);
    setStrength(null);
  }, []);

  const analyzePassword = (pwd: string) => {
    const issues: string[] = [];
    const strengths: string[] = [];
    let score = 0;

    if (pwd.length >= 12) {
      score += 30;
      strengths.push("Good length (12+ characters)");
    } else if (pwd.length >= 8) {
      score += 15;
      strengths.push("Adequate length");
    } else {
      issues.push("Too short (minimum 8 characters)");
    }

    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) {
      score += 20;
      strengths.push("Mixed case letters");
    } else {
      issues.push("Missing uppercase or lowercase letters");
    }

    if (/\d/.test(pwd)) {
      score += 20;
      strengths.push("Contains numbers");
    } else {
      issues.push("No numbers included");
    }

    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd)) {
      score += 20;
      strengths.push("Contains special characters");
    } else {
      issues.push("No special characters");
    }

    const commonPatterns = ['123', 'password', 'qwerty', 'abc', 'admin'];
    const hasCommonPattern = commonPatterns.some(pattern => 
      pwd.toLowerCase().includes(pattern)
    );
    
    if (hasCommonPattern) {
      score -= 30;
      issues.push("Contains common patterns");
    } else {
      score += 10;
      strengths.push("No common patterns");
    }

    return { score: Math.max(0, Math.min(100, score)), issues, strengths };
  };

  const handleCheck = () => {
    if (!password) return;

    const result = analyzePassword(password);
    setStrength(result);
    setShowResult(true);

    if (result.score >= 70) {
      playSuccess();
      setChallengeResult({
        correct: true,
        explanation: "Great password! It's strong and would be difficult for hackers to crack using common methods.",
        tip: "Remember: Never reuse passwords across different accounts. Consider using a password manager to keep track of unique passwords for each service."
      });
      completeScenario("password", true);
    } else {
      playHit();
      setChallengeResult({
        correct: false,
        explanation: `Your password scored ${result.score}/100. While any password is better than none, stronger passwords protect you better from automated hacking tools.`,
        tip: "Strong passwords should be at least 12 characters long and include uppercase, lowercase, numbers, and special characters. Avoid personal information or common words."
      });
      completeScenario("password", false);
    }
  };

  const handleContinue = () => {
    setPhase("feedback");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-purple-900 via-pink-900 to-red-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <Lock className="w-8 h-8 text-purple-600" />
            <h2 className="text-3xl font-bold text-gray-900">Scenario: Creating a Password</h2>
          </div>

          <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-800">
              You're creating a new account for social media. Choose a strong password that will protect your personal information from hackers.
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">Password Strength Checklist:</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-green-600">✓</span>
                At least 12 characters long
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">✓</span>
                Mix of uppercase and lowercase letters
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">✓</span>
                Include numbers
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">✓</span>
                Include special characters (!@#$%^&*)
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600">✗</span>
                Avoid common words or patterns
              </li>
            </ul>
          </div>

          {!showResult ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Create Your Password:
                </label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password..."
                    className="pr-12 text-lg py-6"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <Button
                onClick={handleCheck}
                disabled={!password}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                Check Password Strength
              </Button>
            </div>
          ) : (
            <div>
              {strength && (
                <div className={`border-2 rounded-lg p-6 mb-4 ${
                  strength.score >= 70
                    ? 'bg-green-50 border-green-400' 
                    : 'bg-yellow-50 border-yellow-400'
                }`}>
                  <div className="flex items-center gap-2 mb-4">
                    {strength.score >= 70 ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-green-900">Strong Password!</h3>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-6 h-6 text-yellow-600" />
                        <h3 className="text-xl font-bold text-yellow-900">Weak Password</h3>
                      </>
                    )}
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-semibold text-gray-900">Strength Score:</span>
                      <span className="text-2xl font-bold text-gray-900">{strength.score}/100</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div 
                        className={`h-3 rounded-full transition-all ${
                          strength.score >= 70 ? 'bg-green-500' :
                          strength.score >= 40 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${strength.score}%` }}
                      />
                    </div>
                  </div>

                  {strength.strengths.length > 0 && (
                    <div className="mb-3">
                      <p className="text-sm font-semibold text-gray-900 mb-1">Strengths:</p>
                      <ul className="text-sm text-gray-700 space-y-1">
                        {strength.strengths.map((s, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                            {s}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {strength.issues.length > 0 && (
                    <div>
                      <p className="text-sm font-semibold text-gray-900 mb-1">Issues:</p>
                      <ul className="text-sm text-gray-700 space-y-1">
                        {strength.issues.map((issue, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-red-600" />
                            {issue}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
              
              <Button 
                onClick={handleContinue}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Continue
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
