import { useState, useEffect } from "react";
import { useCyberGame } from "@/lib/stores/useCyberGame";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, AlertTriangle, CheckCircle2, ExternalLink } from "lucide-react";

export default function SocialScenario() {
  const { setPhase, completeScenario, setChallengeResult } = useCyberGame();
  const { playSuccess, playHit } = useAudio();
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    setSelectedOption(null);
    setShowResult(false);
  }, []);

  const message = {
    from: "Jessica Miller",
    avatar: "👤",
    content: "Hey! I found this amazing website where you can get free gift cards! I already got $500! Click here to claim yours before they run out: bit.ly/free-gift-cards-now",
    profileNote: "Not in your contacts • 0 mutual friends"
  };

  const options = [
    {
      id: "click",
      text: "Click the link to check it out - free money sounds great!",
      correct: false
    },
    {
      id: "share",
      text: "Share it with my friends so they can benefit too",
      correct: false
    },
    {
      id: "ignore",
      text: "Delete the message and block the sender - this is likely a scam",
      correct: true
    },
    {
      id: "ask",
      text: "Reply asking for more details about the offer",
      correct: false
    }
  ];

  const handleChoice = (optionId: string) => {
    const option = options.find(o => o.id === optionId);
    if (!option) return;

    setSelectedOption(optionId);
    setShowResult(true);

    if (option.correct) {
      playSuccess();
      setChallengeResult({
        correct: true,
        explanation: "Perfect! You recognized the signs of a social engineering scam. Strangers promising free money or prizes are almost always trying to steal your information or money.",
        tip: "Be skeptical of unsolicited messages, especially from strangers. Legitimate companies don't give away money through random messages. If something sounds too good to be true, it probably is."
      });
      completeScenario("social", true);
    } else {
      playHit();
      let explanation = "";
      if (optionId === "click") {
        explanation = "Clicking suspicious links can lead to phishing sites that steal your information, install malware, or charge hidden fees.";
      } else if (optionId === "share") {
        explanation = "Sharing scam links spreads the threat to your friends and family, making you an unwitting accomplice to the scammer.";
      } else if (optionId === "ask") {
        explanation = "Engaging with scammers confirms your account is active and may lead to more sophisticated attacks tailored to you.";
      }
      
      setChallengeResult({
        correct: false,
        explanation: `Dangerous! ${explanation} The safe action is to ignore and block suspicious messages.`,
        tip: "Red flags: Messages from strangers, too-good-to-be-true offers, shortened URLs (bit.ly), urgency tactics ('before they run out'), requests to click links, and promises of free money."
      });
      completeScenario("social", false);
    }
  };

  const handleContinue = () => {
    setPhase("feedback");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-pink-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <MessageSquare className="w-8 h-8 text-pink-600" />
            <h2 className="text-3xl font-bold text-gray-900">Scenario: Suspicious Message</h2>
          </div>

          <div className="bg-orange-50 border-2 border-orange-300 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-800">
                You receive a direct message on social media from someone you don't know. Read it carefully.
              </p>
            </div>
          </div>

          <div className="bg-white border-2 border-gray-300 rounded-lg p-6 mb-6 shadow-sm">
            <div className="flex items-start gap-4 mb-4 pb-4 border-b">
              <div className="text-4xl">{message.avatar}</div>
              <div className="flex-1">
                <div className="font-bold text-gray-900">{message.from}</div>
                <div className="text-xs text-red-600 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  {message.profileNote}
                </div>
              </div>
            </div>
            
            <div className="bg-blue-50 rounded-lg p-4 mb-3">
              <p className="text-gray-800">{message.content}</p>
            </div>

            <div className="flex items-center gap-2 text-sm text-blue-600">
              <ExternalLink className="w-4 h-4" />
              <span className="font-mono">bit.ly/free-gift-cards-now</span>
            </div>
          </div>

          {!showResult ? (
            <div className="space-y-3">
              <p className="font-semibold text-gray-900 mb-3">What should you do?</p>
              {options.map((option) => (
                <Button
                  key={option.id}
                  onClick={() => handleChoice(option.id)}
                  variant="outline"
                  className="w-full justify-start text-left h-auto py-4 px-4 hover:bg-pink-50 hover:border-pink-400"
                >
                  {option.text}
                </Button>
              ))}
            </div>
          ) : (
            <div>
              {selectedOption && (
                <div className={`border-2 rounded-lg p-6 mb-4 ${
                  options.find(o => o.id === selectedOption)?.correct 
                    ? 'bg-green-50 border-green-400' 
                    : 'bg-red-50 border-red-400'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    {options.find(o => o.id === selectedOption)?.correct ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-green-900">Smart Move!</h3>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                        <h3 className="text-xl font-bold text-red-900">That's Risky!</h3>
                      </>
                    )}
                  </div>
                  <p className="text-gray-800 font-semibold mb-2">Your choice:</p>
                  <p className="text-gray-700 mb-4">{options.find(o => o.id === selectedOption)?.text}</p>
                </div>
              )}

              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h4 className="font-semibold text-gray-900 mb-2 text-sm">Social Engineering Warning Signs:</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>✗ Messages from strangers or unknown accounts</li>
                  <li>✗ Too-good-to-be-true offers (free money, prizes)</li>
                  <li>✗ Shortened or suspicious links (bit.ly, tinyurl)</li>
                  <li>✗ Urgency tactics ("limited time", "act now")</li>
                  <li>✗ Poor grammar or spelling errors</li>
                  <li>✗ Requests for personal information or login credentials</li>
                </ul>
              </div>
              
              <Button 
                onClick={handleContinue}
                className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Continue
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
