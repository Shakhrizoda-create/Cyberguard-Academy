import { useBadges } from "@/lib/stores/useBadges";
import { Card, CardContent } from "@/components/ui/card";
import { Award } from "lucide-react";

interface BadgesDisplayProps {
  compact?: boolean;
}

export default function BadgesDisplay({ compact = false }: BadgesDisplayProps) {
  const { badges } = useBadges();
  const earnedBadges = badges.filter(b => b.earned);
  const totalBadges = badges.length;

  if (compact) {
    return (
      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-600" />
            <span className="font-semibold text-gray-900">Badges Earned</span>
          </div>
          <span className="text-2xl font-bold text-yellow-600">
            {earnedBadges.length}/{totalBadges}
          </span>
        </div>
        {earnedBadges.length > 0 && (
          <div className="flex gap-2 mt-3 flex-wrap">
            {earnedBadges.map((badge) => (
              <div
                key={badge.id}
                className="bg-white rounded-lg p-2 shadow-sm"
                title={badge.name}
              >
                <span className="text-2xl">{badge.icon}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <Award className="w-6 h-6 text-yellow-600" />
          <h3 className="text-xl font-bold text-gray-900">Your Achievements</h3>
          <span className="ml-auto text-lg font-semibold text-gray-600">
            {earnedBadges.length}/{totalBadges}
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`border-2 rounded-lg p-4 transition-all ${
                badge.earned
                  ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-300 shadow-sm'
                  : 'bg-gray-50 border-gray-200 opacity-50'
              }`}
            >
              <div className="text-center">
                <div className={`text-4xl mb-2 ${badge.earned ? 'animate-pulse' : 'grayscale'}`}>
                  {badge.icon}
                </div>
                <h4 className="font-bold text-sm text-gray-900 mb-1">{badge.name}</h4>
                <p className="text-xs text-gray-600">{badge.description}</p>
                {badge.earned && badge.earnedAt && (
                  <p className="text-xs text-green-600 mt-2 font-semibold">
                    ✓ Earned!
                  </p>
                )}
                {!badge.earned && (
                  <p className="text-xs text-gray-400 mt-2">
                    🔒 Locked
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>

        {earnedBadges.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <p>Complete scenarios to earn badges!</p>
          </div>
        )}

        {earnedBadges.length > 0 && earnedBadges.length === totalBadges && (
          <div className="mt-6 bg-gradient-to-r from-yellow-100 to-orange-100 border-2 border-yellow-400 rounded-lg p-4 text-center">
            <p className="text-lg font-bold text-gray-900">
              🎉 Congratulations! You've earned all badges! 🎉
            </p>
            <p className="text-sm text-gray-700 mt-1">
              You're a true cybersecurity champion!
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
