import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, AlertCircle } from "lucide-react";

interface Statistic {
  value: string;
  description: string;
  source?: string;
}

const cyberSecurityStats: Record<string, Statistic[]> = {
  phishing: [
    {
      value: "3.4 billion",
      description: "Phishing emails are sent every day worldwide",
      source: "Cybersecurity Ventures, 2024"
    },
    {
      value: "90%",
      description: "Of successful data breaches start with a phishing email",
      source: "IBM Security Report"
    },
    {
      value: "$12,000",
      description: "Average cost of falling victim to a phishing scam",
      source: "FBI IC3 Report"
    }
  ],
  password: [
    {
      value: "81%",
      description: "Of hacking-related breaches use stolen or weak passwords",
      source: "Verizon Data Breach Report"
    },
    {
      value: "23.2 million",
      description: "People still use '123456' as their password",
      source: "NordPass Study 2024"
    },
    {
      value: "5 minutes",
      description: "Time for hackers to crack a simple 8-character password",
      source: "Hive Systems Research"
    }
  ],
  wifi: [
    {
      value: "25%",
      description: "Of public WiFi hotspots don't use any encryption",
      source: "Kaspersky Security Report"
    },
    {
      value: "43%",
      description: "Of people have accessed sensitive accounts on public WiFi",
      source: "Norton Cyber Safety Survey"
    },
    {
      value: "$200-500",
      description: "Cost of equipment hackers need to intercept public WiFi",
      source: "Security Researchers"
    }
  ],
  social: [
    {
      value: "$5.8 billion",
      description: "Lost to social engineering scams in 2023",
      source: "FBI IC3 Report"
    },
    {
      value: "1 in 3",
      description: "People have clicked on a suspicious link from a stranger",
      source: "Pew Research Center"
    },
    {
      value: "98%",
      description: "Of cyber attacks rely on social engineering tactics",
      source: "Purplesec Statistics"
    }
  ],
  twofactor: [
    {
      value: "99.9%",
      description: "Reduction in account compromise when using 2FA",
      source: "Microsoft Security Study"
    },
    {
      value: "Only 28%",
      description: "Of people actually enable two-factor authentication",
      source: "Google Security Survey"
    },
    {
      value: "10,000+",
      description: "Passwords can be tested per second by automated tools",
      source: "Security Research"
    }
  ],
  privacy: [
    {
      value: "79%",
      description: "Of mobile apps collect more data than necessary",
      source: "Privacy International Study"
    },
    {
      value: "$200/year",
      description: "Value of your personal data to data brokers",
      source: "Kaspersky Research"
    },
    {
      value: "87%",
      description: "Of people don't read app permission requests carefully",
      source: "Pew Research"
    }
  ]
};

interface StatisticsPanelProps {
  scenarioType: string;
}

export default function StatisticsPanel({ scenarioType }: StatisticsPanelProps) {
  const stats = cyberSecurityStats[scenarioType] || [];

  if (stats.length === 0) return null;

  return (
    <Card className="w-full bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          <h3 className="font-bold text-gray-900">Real-World Impact</h3>
        </div>
        
        <div className="space-y-4">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg p-4 border border-blue-100">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-3xl font-bold text-blue-600 mb-1">{stat.value}</p>
                  <p className="text-sm text-gray-800 mb-1">{stat.description}</p>
                  {stat.source && (
                    <p className="text-xs text-gray-500 italic">Source: {stat.source}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-400 rounded p-3">
          <p className="text-sm text-gray-800">
            <strong>⚠️ Local Impact:</strong> Hacking and cyber fraud are common in your community. 
            These statistics show why learning cybersecurity is essential for protecting yourself and your loved ones.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
