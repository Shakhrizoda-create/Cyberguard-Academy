import { useCyberGame } from "@/lib/stores/useCyberGame";
import PhishingScenario from "./scenarios/PhishingScenario";
import PasswordScenario from "./scenarios/PasswordScenario";
import WiFiScenario from "./scenarios/WiFiScenario";
import SocialScenario from "./scenarios/SocialScenario";
import TwoFactorScenario from "./scenarios/TwoFactorScenario";
import PrivacyScenario from "./scenarios/PrivacyScenario";

export default function ScenarioScreen() {
  const { currentScenario } = useCyberGame();

  if (!currentScenario) return null;

  switch (currentScenario) {
    case "phishing":
      return <PhishingScenario />;
    case "password":
      return <PasswordScenario />;
    case "wifi":
      return <WiFiScenario />;
    case "social":
      return <SocialScenario />;
    case "twofactor":
      return <TwoFactorScenario />;
    case "privacy":
      return <PrivacyScenario />;
    default:
      return null;
  }
}
