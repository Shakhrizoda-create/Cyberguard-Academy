import { useCyberGame } from "@/lib/stores/useCyberGame";
import MainMenu from "@/components/MainMenu";
import IntroScreen from "@/components/IntroScreen";
import ScenarioScreen from "@/components/ScenarioScreen";
import FeedbackScreen from "@/components/FeedbackScreen";
import CompleteScreen from "@/components/CompleteScreen";
import GameUI from "@/components/GameUI";
import SoundManager from "@/components/SoundManager";
import "@fontsource/inter";

function App() {
  const { phase } = useCyberGame();

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {phase !== "menu" && <GameUI />}
      
      {phase === "menu" && <MainMenu />}
      {phase === "intro" && <IntroScreen />}
      {phase === "scenario" && <ScenarioScreen />}
      {phase === "feedback" && <FeedbackScreen />}
      {phase === "complete" && <CompleteScreen />}
      
      <SoundManager />
    </div>
  );
}

export default App;
