
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
}
import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        cyberblue: '#2563eb',   // custom color for CyberGuard
        cybershield: '#1e293b', // dark background
        warning: '#facc15',     // yellow alert
        danger: '#ef4444',      // red alert
        success: '#22c55e',     // green success
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

export default config
content: ['./index.html', './src/components/**/*.{js,ts,jsx,tsx}']
