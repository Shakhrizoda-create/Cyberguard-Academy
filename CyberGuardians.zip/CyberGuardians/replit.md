# CyberGuard Academy

## Overview

CyberGuard Academy is an interactive cybersecurity awareness game designed to educate users about common cyber threats through scenario-based learning. The application presents users with real-world cybersecurity challenges including phishing detection, password security, WiFi safety, and social engineering awareness. Users navigate through interactive scenarios, make decisions, and receive immediate feedback with educational content.

The application follows a full-stack architecture with a React-based frontend and Express backend, using PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React with TypeScript for type-safe component development
- Vite as the build tool and development server, providing fast HMR (Hot Module Replacement)
- Client-side routing implemented through phase-based navigation rather than traditional URL routing

**UI Component System**
- Radix UI primitives for accessible, unstyled UI components
- Tailwind CSS for utility-first styling with custom theme configuration
- shadcn/ui component patterns for consistent, reusable UI elements
- Custom CSS variables for theming (colors, spacing, borders)

**State Management**
- Zustand for lightweight, hook-based global state management
- Three primary stores:
  - `useCyberGame`: Manages game logic, scenarios, scoring, and progression
  - `useAudio`: Controls sound effects and background music
  - `useBadges`: Manages achievements, badges, and learning milestones with persistence
- `subscribeWithSelector` middleware enables granular state subscriptions
- Zustand persist middleware for badge data persistence across sessions

**Game Flow Architecture**
- Phase-based navigation system with states: menu → intro → scenario → feedback → complete
- Scenario-driven progression with six educational modules:
  - Phishing detection
  - Password security
  - WiFi safety
  - Social engineering awareness
  - Two-factor authentication
  - Data privacy and app permissions
- Component-per-phase architecture for clear separation of concerns
- Badges and achievements system to reward learning milestones
- Real-world cybersecurity statistics integrated into feedback screens

**3D Graphics Support**
- React Three Fiber integration for WebGL rendering
- Three.js ecosystem support with @react-three/drei utilities
- GLSL shader support via vite-plugin-glsl
- Asset handling for 3D models (.gltf, .glb) and audio files

### Backend Architecture

**Server Framework**
- Express.js for HTTP server and API routing
- Middleware-based request processing
- Custom logging middleware for API request tracking
- Error handling middleware for centralized error responses

**Storage Layer**
- Abstract storage interface (`IStorage`) defining CRUD operations
- In-memory implementation (`MemStorage`) for development/testing
- Designed for easy migration to database-backed storage
- User management with username uniqueness constraints

**Development Tooling**
- Vite middleware integration in development mode
- Custom error overlay plugin for runtime error display
- Hot module replacement for rapid development iteration
- Separate build processes for client (Vite) and server (esbuild)

**API Design**
- RESTful conventions with `/api` prefix for all endpoints
- JSON request/response format
- Session-based authentication prepared (connect-pg-simple integration)
- CORS and credential handling configured

### Data Storage Solutions

**Database**
- PostgreSQL as the primary relational database
- Neon serverless PostgreSQL connector for cloud deployment
- Drizzle ORM for type-safe database operations
- Schema-first approach with TypeScript inference

**Schema Management**
- Drizzle Kit for schema migrations and push operations
- Schema defined in shared directory for client-server type consistency
- Zod integration for runtime validation of database inputs
- Migration files tracked in dedicated migrations directory

**Current Schema**
- Users table with username/password authentication
- Serial primary keys for entity identification
- Unique constraints on usernames

### External Dependencies

**UI Component Libraries**
- @radix-ui/* - 20+ accessible, unstyled component primitives
- Lucide React - Icon library for consistent iconography
- cmdk - Command palette/menu implementation

**3D Graphics & Animation**
- @react-three/fiber - React renderer for Three.js
- @react-three/drei - Helper components for 3D scenes
- @react-three/postprocessing - Post-processing effects
- Three.js - Core 3D graphics library

**Data & State Management**
- Zustand - Lightweight state management
- @tanstack/react-query - Server state synchronization (configured but not actively used)
- Zod - Runtime type validation

**Database & ORM**
- @neondatabase/serverless - Serverless PostgreSQL client
- Drizzle ORM - Type-safe database toolkit
- connect-pg-simple - PostgreSQL session store (prepared for authentication)

**Utilities**
- date-fns - Date manipulation and formatting
- class-variance-authority - Component variant management
- clsx & tailwind-merge - Conditional className utilities
- nanoid - Unique ID generation

**Build & Development Tools**
- Vite - Build tool and dev server
- esbuild - JavaScript bundler for production server
- TypeScript - Type system and compiler
- PostCSS & Autoprefixer - CSS processing
- @replit/vite-plugin-runtime-error-modal - Development error overlay

**Font & Styling**
- @fontsource/inter - Self-hosted Inter font family
- Tailwind CSS - Utility-first CSS framework

**Audio Management**
- Native HTML5 Audio API for sound effects and background music
- Three audio file formats supported: MP3, OGG, WAV
- Custom Zustand store for centralized audio control