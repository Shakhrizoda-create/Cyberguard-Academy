document.getElementById("social-btn").addEventListener("click", openSocialGame);

function openSocialGame() {
  // Hide the main menu
  document.querySelector(".main-menu").style.display = "none";
  // Show the game area
  document.querySelector("#social-game").style.display = "block";
}
function checkAnswer(choice) {
  const result = document.getElementById("result");
  if (choice === 'A') {
    result.textContent = "✅ Correct! That was a phishing attempt.";
  } else {
    result.textContent = "❌ Oops! That one was safe.";
  }
}

function goBack() {
  document.querySelector("#social-game").style.display = "none";
  document.querySelector(".main-menu").style.display = "block";
}
